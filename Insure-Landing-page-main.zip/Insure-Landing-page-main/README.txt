
The main goal for this project is to make it responsive on all screen sizes.

Design source: frontendmentor.io

Thanks for reading this :) bye
